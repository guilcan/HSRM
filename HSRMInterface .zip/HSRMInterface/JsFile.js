function tableAppend(){
    var temp1 = document.getElementsByTagName("table")[0];
    var tr1 = document.createElement("tr");
    var tr2 = document.createElement("tr");
    var atributo = document.getElementByTagName("input")[3].innerHTML;
    var valor = document.getElementByTagName("input")[4].innerHTML;

    var text1 = document.createTextNode(atributo);
    var text2 = document.createTextNode(valor);

    var th = document.createElement('th');
    var td = document.createElement('td');

    th.appendChild(text1);
    td.appendChild(text2);
    tr1.appendChild(th);
    tr2.appendChild(td);

    temp1.appendChild(tr1);
    temp1.appendChild(tr2);


}